import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import AgencyMember from "./AgencyMember";
import {Button} from "react-bootstrap"
export default class MemberTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: "agencymember",
    };
  }
  ChangeTab = (type) => (e) => {
    this.setState({
      type: type,
    });
  };
  render() {
    return (
      <>
        <div className="user-tabs-main">
          <div className="user-tabs">
            <ul>
              <li>
                <NavLink
                  to="#"
                  onClick={this.ChangeTab("agencymember")}
                  activeClassName={
                    this.state.type === "agencymember" ? "active-user" : ""
                  }
                >
                  Members
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="#"
                  onClick={this.ChangeTab("updaterate")}
                  activeClassName={
                    this.state.type === "updaterate" ? "active-user" : ""
                  }
                >
                  Update Rate
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="#"
                  onClick={this.ChangeTab("newreguest")}
                  activeClassName={
                    this.state.type === "newreguest" ? "active-user" : ""
                  }
                >
                  New Request
                </NavLink>
              </li>
              <li style={{ float: "right" }}>
                <Button variant="false" className="btn btn-light">
                  <i className="fa fa-plus-square-o"></i> ADD
                </Button>
              </li>
            </ul>
          </div>
        </div>
        {this.state.type === "agencymember" ? <AgencyMember /> : ""}
      </>
    );
  }
}
