import React, { Component } from 'react'

export default class AgencyMember extends Component {
    render() {
        return (
          <>
            <div className="edit-profilebox"> meber</div>
          </>
        );
    }
}
