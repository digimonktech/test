import React, { Component } from "react";

export default class Radio extends Component {
  constructor() {
    super();
    this.state = {
      gender: "",
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;
    this.setState({ [name]: value === "male" ? 1 : 0 });
  }

  render() {
    const GENDER_TYPE = {
      1: <input type="date" className="form-control" />,
    };

    return (
      <div className="App">
        <h1>Radio batton example</h1>
        <label>
          <input
            type="radio"
            name="gender"
            value="male"
            checked={this.state.gender === 1}
            onChange={this.handleChange}
          />{" "}
          Male
        </label>

        <p>{GENDER_TYPE[this.state.gender]}</p>
      </div>
    );
  }
}
